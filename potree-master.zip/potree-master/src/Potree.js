


function Potree(){
	
}

// contains WebWorkers with base64 encoded code
Potree.workers = {};

Potree.Shaders = {};

