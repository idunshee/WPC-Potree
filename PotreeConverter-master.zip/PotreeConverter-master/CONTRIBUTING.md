
## How to contribute

* Make sure you have a GitHub account
* Fork the repository on GitHub
* Make changes to your clone of the repository
* Submit a pull request to the `dev` branch
